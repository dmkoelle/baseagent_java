package org.baseagent.comms;

public interface MessageListener {
	public void onMessageReceived(Message message);
}
