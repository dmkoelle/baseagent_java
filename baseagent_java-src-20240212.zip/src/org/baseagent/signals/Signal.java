package org.baseagent.signals;

import org.baseagent.grid.GridLayer;

public class Signal {
	private String signalName;
	private GridLayer gridLayer;
	
	public Signal(String name) {
		this.signalName = name;
//		this.gridLayer = gridLayer;
	}
	

}
