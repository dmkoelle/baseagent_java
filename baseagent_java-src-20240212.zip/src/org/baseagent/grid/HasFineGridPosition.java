package org.baseagent.grid;

public interface HasFineGridPosition extends HasGridPosition {
	public void setFineX(double x);
	public double getFineX();
	public void setFineY(double y);
	public double getFineY();
}
