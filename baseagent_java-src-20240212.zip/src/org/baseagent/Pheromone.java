package org.baseagent;

/** A pheromone is a beacon that dissipates over time and eventually goes away */
public class Pheromone extends Beacon {

}
