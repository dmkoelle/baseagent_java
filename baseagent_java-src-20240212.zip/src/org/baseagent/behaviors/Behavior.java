package org.baseagent.behaviors;

import org.baseagent.Agent;

public interface Behavior {
	public void executeBehavior(Agent agent);
}
