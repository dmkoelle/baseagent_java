package org.baseagent.embodied.behaviors;

import org.baseagent.behaviors.Behavior;
import org.baseagent.comms.MessageListener;
import org.baseagent.embodied.EmbodiedAgent;

public class TakeAndDropBehavior implements Behavior, MessageListener {
	public TakeAndDropBehavior(EmbodiedAgent agent) {
		// TODO - Whoo boy, I don't know about this EmbodiedFullStackBehavior deal. I could come up with 1000 slightly different behaviors.
		// But the IDEA of a full-stack behavior is interesting. 
	}
}
