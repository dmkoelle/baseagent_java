package org.baseagent.behaviors;

public interface LifecycleBehavior extends Behavior {
	public void startBehavior();
	public void endBehavior();
}
