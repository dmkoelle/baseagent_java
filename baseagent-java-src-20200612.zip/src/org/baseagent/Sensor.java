package org.baseagent;

public interface Sensor {
	public abstract void sense(Agent agent);
}
