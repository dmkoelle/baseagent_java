package org.baseagent.mindplan;

import org.baseagent.sim.Simulation;

public interface Satisfiable {
	public boolean isSatisfied(Simulation sim);

}
