package org.baseagent.path;

public class Sink extends PathComponent {
	public Sink(int x, int y) {
		super(x, y);
	}

}
