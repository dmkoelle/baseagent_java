package org.baseagent;

import org.baseagent.sim.Simulation;

public interface HasStep {
	public void step(Simulation simulation);
}
