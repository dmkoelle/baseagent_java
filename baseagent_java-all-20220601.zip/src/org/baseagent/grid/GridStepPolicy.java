package org.baseagent.grid;

public interface GridStepPolicy {
	public void step();
}
