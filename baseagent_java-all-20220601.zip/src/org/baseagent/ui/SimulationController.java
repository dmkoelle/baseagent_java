package org.baseagent.ui;

import org.baseagent.sim.Simulation;

import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class SimulationController {
	private Button pauseButton = new Button();
	private Button stopButton = new Button();
	private Label timeStepLabel = new Label();
	private Simulation simulation;
	
	public SimulationController(Simulation simulation) {
		super();
		
		
	}
}
