package org.baseagent.embodied.effectors;

import org.baseagent.Agent;

public interface Effector {
	public abstract void effect(Agent agent);
}
