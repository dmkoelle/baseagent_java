package org.baseagent.metrics;

import org.baseagent.sim.Simulation;

public interface Metric {
	public void evaluate(Simulation sim);
}
