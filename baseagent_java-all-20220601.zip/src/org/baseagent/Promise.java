package org.baseagent;

import java.util.function.Predicate;

public class Promise {
	public Promise(long atLeastBy, long noLaterThan, Predicate condition) {
		
	}

}
