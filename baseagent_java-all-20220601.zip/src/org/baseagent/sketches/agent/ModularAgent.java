package org.baseagent.sketches.agent;

public interface ModularAgent {

}
