package org.baseagent.signals;

import org.baseagent.sim.Simulation;

public interface SignalPropagation {
	public void propagateSignal(Simulation simulation);
}
