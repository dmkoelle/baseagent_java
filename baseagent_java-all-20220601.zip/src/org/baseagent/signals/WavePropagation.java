package org.baseagent.signals;

import org.baseagent.sim.Simulation;

public class WavePropagation implements SignalPropagation {

	@Override
	public void propagateSignal(Simulation simulation) {
		// TODO Auto-generated method stub
		
	}
	

}
