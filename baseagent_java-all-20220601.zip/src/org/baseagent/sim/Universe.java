package org.baseagent.sim;

public interface Universe extends SimulationListener {
	
}
