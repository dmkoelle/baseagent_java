package org.baseagent.blocks;

import org.baseagent.embodied.ConnectedComponent;

public class Block extends ConnectedComponent {
	public Block(String name, )
}
