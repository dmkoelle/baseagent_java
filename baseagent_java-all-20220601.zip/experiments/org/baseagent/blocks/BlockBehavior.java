package org.baseagent.blocks;

import org.baseagent.Agent;
import org.baseagent.behaviors.Behavior;

public class BlockBehavior implements Behavior {
	private List<Block> blocks;
	
	public BlockBehavior() {
		
	}
	
	
	@Override
	public void executeBehavior(Agent agent) {
		// TODO Auto-generated method stub
		
	}

}
